from airflow.hooks.postgres_hook import PostgresHook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
import logging


class DataQualityOperator(BaseOperator):

    ui_color = '#89DA59'

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 table=[],
                 *args, **kwargs):

        super(DataQualityOperator, self).__init__(*args, **kwargs)
        self.redshift_conn_id = redshift_conn_id
        self.table = table

    def execute(self, context):
        self.log.info('DataQualityOperator started')
        redshift = PostgresHook(postgres_conn_id=self.redshift_conn_id)

        # check_sql = "SELECT COUNT(*) FROM {}".format(self.table)

        dq_checks = [
            {'check_sql': "SELECT COUNT(*) FROM users WHERE userid is null", 'expected_result': 0},
            {'check_sql': "SELECT COUNT(*) FROM songs WHERE songid is null", 'expected_result': 0},
            {'check_sql': "SELECT COUNT(*) FROM artists WHERE artistid is null", 'expected_result': 0}
        ]

        records = redshift.get_records(dq_checks)

        if len(records[0]) < 1:
            logging.error("No records found in {} table".format(self.table))
            raise ValueError("No records found in {} table".format(self.table))
        else:
            self.log.info('DataQualityOperator completed without error')


